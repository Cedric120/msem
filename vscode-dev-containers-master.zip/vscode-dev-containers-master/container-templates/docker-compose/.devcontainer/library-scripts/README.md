# Warning: Folder contents may be replaced

The contents of this folder will be automatically replaced with a file of the same name in the [vscode-dev-containers](https://github.com/microsoft/vscode-dev-containers) repository's [script-library folder](https://github.com/microsoft/vscode-dev-containers/tree/master/script-library) whenever the repository is packaged.

To retain your edits, move the file to a different location. You may also delete the files if they are not needed.