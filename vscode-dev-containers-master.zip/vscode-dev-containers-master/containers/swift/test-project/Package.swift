// swift-tools-version:4.0
/*--------------------------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See https://go.microsoft.com/fwlink/?linkid=2090316 for license information.
 *-------------------------------------------------------------------------------------------------------------*/

import PackageDescription

let package = Package(
    name: "HelloWorld",
    targets: [
        .target(name:"HelloWorld")
    ]
)