# A sample R script

myString <- "Hello, Remote World!"
print ( myString)