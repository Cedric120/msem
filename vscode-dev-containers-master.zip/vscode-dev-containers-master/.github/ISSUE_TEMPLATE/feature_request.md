---
name: Feature request
about: Suggest an idea for this project

---

<!--  🚨 Please only include feature requests related to Dev Container Definitions here. 🚨 Other locations:
        VS Code Remote Development: http://github.com/Microsoft/vscode-remote-release 
        VS Code OSS: http://github.com/Microsoft/vscode
-->

<!-- Describe the feature request -->